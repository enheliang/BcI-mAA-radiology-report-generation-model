# import numpy as np
# import matplotlib.pyplot as plt
# import pandas as pd
# import matplotlib.font_manager as fm
#
# data1 = pd.read_csv('./1.csv')
# color = ['red','green','blue','yellow','pink','black','purple']
#
#
# df = pd.DataFrame(data1)
# df.plot.box(title="example show")
# plt.grid(linestyle="--", alpha=0.3)
# plt.savefig('./results_imgs.png', bbox_inches='tight')
# plt.show()
import matplotlib.pyplot as plt
import pandas as pd
import matplotlib.font_manager as fm

data1 = pd.read_csv('./1.csv')
color = ['red','green','blue','yellow','pink','black','purple']

df = pd.DataFrame(data1)

# 查找新罗马字体的文件路径
font_path = fm.findfont(fm.FontProperties(family='serif'))

# 创建字体对象
font_name = fm.FontProperties(fname=font_path).get_name()

# 修改全局字体设置
plt.rcParams['font.family'] = font_name

# 绘制箱线图
df.plot.box(title="", patch_artist=True)
# 设置颜色
box_colors = ['red', 'green', 'blue', 'yellow', 'purple', 'orange','black']
for patch, color in zip(plt.gca().patches, box_colors):
    patch.set_facecolor(color)
plt.grid(linestyle="--", alpha=0.3)
plt.savefig('./results_imgs.png', bbox_inches='tight')
plt.show()