from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import copy
import math

import numpy as np
import scipy
import torch
import torch.nn as nn
import torch.nn.functional as F
import pickle
from .utils import my_con_loss

from .att_model import pack_wrapper, AttModel


def clones(module, N):
    return nn.ModuleList([copy.deepcopy(module) for _ in range(N)])


def subsequent_mask(size):  # 用于在自注意力机制（self-attention）中屏蔽未来时刻的信息
    attn_shape = (1, size, size)  # 表示遮蔽矩阵的形状。这里的遮蔽矩阵是一个三维矩阵，第一个维度为1，表示只有一个样本；后两个维度为size，表示矩阵的大小
    subsequent_mask = np.triu(np.ones(attn_shape), k=1).astype(
        'uint8')  # 使用NumPy库创建一个大小为size × size的上三角矩阵，其中上三角矩阵的主对角线和主对角线以上的元素都为1，其余元素都为0，然后np.triu函数将其转换为上三角矩阵，k=1表示主对角线以上的元素都被置为0。最后，.astype('uint8')将矩阵的数据类型转换为无符号8位整数。
    return torch.from_numpy(subsequent_mask) == 0  # 将遮蔽矩阵中的0元素替换为False，非零元素替换为True


def attention(query, key, value, mask=None, dropout=None):
    d_k = query.size(-1)  # 获取查询向量 query 的最后一个维度的大小，也就是注意力机制中的 k，表示查询向量的维度。
    scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(d_k)  # 计算查询向量 query 和键向量 key 之间的点积得分
    if mask is not None:
        scores = scores.masked_fill(mask == 0, float('-inf'))  # 将掩码应用到得分上,将得分中与掩码值为0的位置对应的得分置为负无穷，以实现屏蔽操作
    p_attn = F.softmax(scores, dim=-1)  # 使用 softmax 函数将得分转换为注意力权重。通过对得分进行 softmax 操作，可以将得分转换为概率分布，用于表示每个位置的重要性。
    if dropout is not None:
        p_attn = dropout(p_attn)  # 传入了 dropout 参数，则对注意力权重 p_attn 进行 dropout 操作，以随机地将一部分注意力权重设置为0，以减少过拟合。
    return torch.matmul(p_attn,
                        value), p_attn  # 返回注意力加权后的值和注意力权重。通过将注意力权重 p_attn 与值向量 value 进行矩阵乘法，可以得到注意力加权后的结果，同时也返回注意力权重 p_attn。


def memory_querying_responding(query, key, value, mask=None, dropout=None, topk=32):  # 在记忆中查询和响应的函数
    d_k = query.size(-1)  # 获取查询向量 query 的最后一个维度的大小，也就是注意力机制中的 k，表示查询向量的维度。
    scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(
        d_k)  # 计算查询向量 query 和键向量 key 之间的点积得分。通过将 query 与 key 的转置相乘，然后除以 sqrt(d_k) 进行缩放，以确保得分具有适当的尺度。
    if mask is not None:
        scores = scores.masked_fill(mask == 0,
                                    float('-inf'))  # 用于将掩码应用到得分上。如果传入了掩码 mask，则将得分中与掩码值为0的位置对应的得分置为负无穷，以实现屏蔽操作。
    selected_scores, idx = scores.topk(topk)  # 选择得分最高的前 topk 个得分，并返回选中的得分和其对应的索引。selected_scores 是选中的得分，idx 是对应的索引。
    # query [8, 8, 49/98, 64]) value [8, 8, 2048, 64] score [8, 8, 49/98, 2048]
    # idx 8x8x98x32
    dummy_value = value.unsqueeze(2).expand(idx.size(0), idx.size(1), idx.size(2), value.size(-2), value.size(
        -1))  # [8, 8, 98, 2048, 64]  #扩展值向量 value，以便与索引 idx 的维度相匹配。通过在维度2上添加一个维度，并进行扩展，使得 dummy_value 的形状与 dummy_idx 的形状一致。
    dummy_idx = idx.unsqueeze(-1).expand(idx.size(0), idx.size(1), idx.size(2), idx.size(3), value.size(
        -1))  # [8, 8, 98, 32, 64]  #扩展索引 idx，以便与值向量 value 的维度相匹配。通过在最后一个维度上添加一个维度，并进行扩展，使得 dummy_idx 的形状与 dummy_value 的形状一致。

    selected_value = torch.gather(dummy_value, 3,
                                  dummy_idx)  # [8, 8, 98, 32, 64]  #使用索引 dummy_idx 从扩展后的值向量 dummy_value 中选择对应位置的值，得到选中的值向量 selected_value。

    p_attn = F.softmax(selected_scores,
                       dim=-1)  # [8, 8, 98, 32]使用 softmax 函数将选中的得分 selected_scores 转换为注意力权重。通过对得分进行 softmax 操作，可以将得分转换为概率分布，用于表示每个位置的重要性。

    if dropout is not None:
        p_attn = dropout(p_attn)  # 传入了 dropout 参数，则对注意力权重 p_attn 进行 dropout 操作，以随机地将一部分注意力权重设置为0，以减少过拟合。
    return torch.matmul(p_attn.unsqueeze(3), selected_value).squeeze(
        3), p_attn  # 将注意力权重 p_attn 在维度3上扩展，并与选中的值向量 selected_value 进行矩阵乘法，然后在维度3上进行挤压，得到最终的结果。同时还返回注意力权重 p_attn。

def DotProductAttention(query, key, value, mask, scale=True):
    if scale:
        depth = query.shape[-1]
    else:
        depth = 1

    dots = torch.matmul(query, key.transpose(-1, -2)) / torch.sqrt(torch.tensor(depth, dtype=torch.float32))

    if mask is not None:
        dots = dots.masked_fill(~mask, float('-inf'))

    attention = torch.matmul(dots.softmax(dim=-1), value)

    return attention

class SelfAttention(nn.Module):
    def __init__(self, hidden_size):
        super(SelfAttention, self).__init__()
        self.hidden_size = hidden_size
        self.query = nn.Linear(hidden_size, hidden_size)
        self.key = nn.Linear(hidden_size, hidden_size)
        self.value = nn.Linear(hidden_size, hidden_size)

    def forward(self, inputs, mask=None):
        query = self.query(inputs)
        key = self.key(inputs)
        value = self.value(inputs)

        scores = torch.matmul(query, key.transpose(-2, -1))
        if mask is not None:
            scores = scores.masked_fill(mask == 0, float("-inf"))

        attention_weights = F.softmax(scores, dim=-1)
        attended_values = torch.matmul(attention_weights, value)

        return attended_values, attention_weights

class Transformer(nn.Module):
    def __init__(self, encoder, decoder, src_embed, tgt_embed, cmn, dropout=0.1):  # 定义了Transformer类的初始化方法
        super(Transformer, self).__init__()
        self.encoder = encoder  # 接受编码器(encoder)、解码器(decoder)、源嵌入层(src_embed)、目标嵌入层(tgt_embed)
        self.decoder = decoder
        self.src_embed = src_embed
        self.tgt_embed = tgt_embed
        self.cmn = cmn  # 用于跨模态原型查询和响应的模块(cmn)作为参数
        self.fc_relu = nn.ReLU()
        self.fc = nn.Linear(512, 512)
        self.dropout = nn.Dropout(p=dropout)
        self.fuse_feature = nn.Linear(512 * 2, 512)  # fuse_feature是一个线性层，用于融合文本特征和响应特征。
        self.fuse_feature1 = nn.Linear(1024, 512)
        self.norm = LayerNorm(512)
        self.DAtt = DotProductAttention
        self.self_attention = SelfAttention(hidden_size=1024)
        self.LayerNorm = LayerNorm
        self.mlp1 = nn.Sequential(
            nn.Linear(1024, 512),
            nn.ReLU(),
            nn.Linear(512, 512)
        )

        self.mlp2 = nn.Sequential(
            nn.Linear(1024, 512),
            nn.ReLU()
        )

        self.mlp3 = nn.Sequential(
            nn.Linear(512, 512),
            nn.ReLU()
        )

        self.batch_norm1 = nn.BatchNorm1d(47)
        self.batch_norm2 = nn.BatchNorm1d(512)


    def forward(self, src, tgt, src_mask, tgt_mask, memory_matrix, cmn_masks=None, labels=None):
        return self.decode(self.encode(src, src_mask), src_mask, tgt, tgt_mask, memory_matrix=memory_matrix,
                           cmn_masks=cmn_masks, labels=labels)  # 对输入的源序列(src)进行编码，然后将编码后的结果作为记忆传递给解码器，并返回解码器的输出。

    def encode(self, src, src_mask):
        return self.encoder(self.src_embed(src),
                            src_mask)  # [12,98,512]  #对源序列进行编码。它首先将源序列进行嵌入(src_embed)，然后将嵌入后的结果输入给编码器(encoder)进行编码，并返回编码后的结果。


class Encoder(nn.Module):
    def __init__(self, layer, N):
        super(Encoder, self).__init__()
        self.layers = clones(layer, N)  # 接受一个编码器层(layer)和编码器层数(N)作为参数，并对它们进行初始化。
        self.norm = LayerNorm(layer.size)  # self.norm是一个层归一化(LayerNorm)层，用于对编码器输出进行归一化处理

    def forward(self, x, mask):  # 接受输入张量(x)和掩码张量(mask)作为参数
        for layer in self.layers:
            x = layer(x, mask)  # 输入张量通过编码器层(layer)进行编码
        return self.norm(x)  # 对编码器的输出进行层归一化(self.norm)处理


class LayerNorm(nn.Module):
    def __init__(self, features, eps=1e-6):
        super(LayerNorm, self).__init__()
        self.a_2 = nn.Parameter(torch.ones(features))
        self.b_2 = nn.Parameter(torch.zeros(features))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        std = x.std(-1, keepdim=True)
        return self.a_2 * (x - mean) / (std + self.eps) + self.b_2


class SublayerConnection(nn.Module):  # 编码器中截进分支操作
    def __init__(self, size, dropout):
        super(SublayerConnection, self).__init__()
        self.norm = LayerNorm(size)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, sublayer):  # 接受输入张量(x)和子层(sublayer)作为参数,
        # 在连接子层之前对输入进行层归一化处理,将归一化后的结果输入给子层进行处理，得到子层的输出(_x)
        _x = self.norm(x)
        _x = sublayer(_x)
        if type(_x) is tuple:
            return x + self.dropout(_x[0]), _x[1]  # 如果子层的输出是一个元组形式，表示有附加的信息，则将输入张量和附加信息进行相加，然后通过丢弃层进行随机丢弃操作
        return x + self.dropout(_x)  # 否则，只将输入张量和子层的输出进行相加，并进行随机丢弃操作


class EncoderLayer(nn.Module):
    def __init__(self, size, self_attn, feed_forward, dropout):
        super(EncoderLayer, self).__init__()
        self.self_attn = self_attn
        self.feed_forward = feed_forward  # 前馈神经网络模块，用于对输入进行前馈网络计算
        self.sublayer = clones(SublayerConnection(size, dropout),
                               2)  # 由两个子层连接(SublayerConnection)层复制而来的层列表，用于连接自注意力和前馈网络
        self.size = size  # self.size表示编码器层的大小。

    def forward(self, x, mask):  # 输入进行自注意力计算和前馈网络计算
        x = self.sublayer[0](x, lambda x: self.self_attn(x, x, x,
                                                         mask))  # 通过子层连接(self.sublayer[0])将输入张量和自注意力计算的结果进行连接，并应用丢弃操作   编码器中第一个多头注意力
        return self.sublayer[1](x,
                                self.feed_forward)  # 连接后的结果输入给前馈网络进行计算，并通过子层连接(self.sublayer[1])将输入张量和前馈网络计算的结果进行连接，并应用丢弃操作   最后得到编码器的输出


class Decoder(nn.Module):  # 用于构建多层解码器。
    def __init__(self, layer, N):
        super(Decoder, self).__init__()
        self.layers = clones(layer, N)  # 接受一个解码器层(layer)和解码器层数(N)作为参数 self.layers是一个由多个解码器层复制而来的层列表，用于构建多层解码器
        self.norm = LayerNorm(layer.d_model)  # self.norm是一个层归一化(LayerNorm)层，用于对解码器输出进行归一化处理

    def forward(self, x, memory, src_mask, tgt_mask,
                past=None):  # 输入张量(x)、记忆张量(memory)、源掩码张量(src_mask)、目标掩码张量(tgt_mask)和过去的记忆(past)作为参数
        if past is not None:  # 如果过去的记忆(past)不为None，则表示当前解码步骤是基于之前的解码结果进行的。
            present = [[], []]  # 创建一个空列表present，用于存储当前步骤的记忆。
            x = x[:, -1:]  # 对输入张量x进行切片，只保留最后一个时间步的信息。这是因为解码器是逐步生成输出序列的，所以只需要最后一个时间步的信息。
            tgt_mask = tgt_mask[:, -1:] if tgt_mask is not None else None  # 对目标掩码张量tgt_mask进行切片，只保留最后一个时间步的掩码信息。
            past = list(zip(past[0].split(2, dim=0), past[1].split(2, dim=0)))  # 将过去的记忆past重新组织为一个列表，其中每个元素是解码器层的过去记忆。
        else:  # 当前解码步骤是从头开始的解码过程
            past = [None] * len(self.layers)  # 将past初始化为一个长度为self.layers的解码器层数的列表，每个元素初始化为None。
        for i, (layer, layer_past) in enumerate(zip(self.layers, past)):  # 循环遍历每个解码器层(layer)和对应的过去记忆(layer_past)，
            x = layer(x, memory, src_mask, tgt_mask,  # 将输入张量、记忆张量、源掩码张量、目标掩码张量和过去记忆传递给解码器层进行解码。
                      layer_past)
            if layer_past is not None:  # 如果解码器层有过去记忆
                present[0].append(x[1][0])  # 将当前步骤的记忆的第一部分添加到present列表中。
                present[1].append(x[1][1])  # 将当前步骤的记忆的第二部分添加到present列表中。
                x = x[0]  # 仅保留解码器层的输出，舍弃记忆部分。
        if past[0] is None:  # 如果past的第一个元素为None，表示当前解码步骤是从头开始的解码过程。
            return self.norm(x)  # v当前解码步骤是从头开始的解码过程。在这种情况下，直接对输入进行解码，并返回解码器的输出
        else:
            return self.norm(x), [torch.cat(present[0], 0), torch.cat(present[1],
                                                                      0)]  # 对解码器的输出x进行层归一化处理，并将当前步骤的记忆present作为一个列表返回。记忆present是通过将当前步骤的记忆的第一部分和第二部分连接在一起而得到的。这里使用了torch.cat函数来连接张量。


class DecoderLayer(nn.Module):
    def __init__(self, d_model, self_attn, src_attn, feed_forward, dropout):
        super(DecoderLayer, self).__init__()
        self.d_model = d_model
        self.self_attn = self_attn  # 对解码器输入进行自注意力计算
        self.src_attn = src_attn  # 源注意力模块(src_attn)，对解码器输入和编码器输出之间的关系进行注意力计算
        self.feed_forward = feed_forward  # 前馈神经网络模块(feed_forward) #对解码器输入进行前馈网络计算。self.sublayer是一个由三个子层连接
        self.sublayer = clones(SublayerConnection(d_model, dropout), 3)  # 用于连接自注意力、源注意力和前馈网络。  截进分支结构

    def forward(self, x, memory, src_mask, tgt_mask, layer_past=None):
        m = memory  # m就是图像特征编码后传入进来的
        if layer_past is None:  # layer_past 为 None，表示这是从头开始的解码过程。
            x = self.sublayer[0](x, lambda x: self.self_attn(x, x, x,
                                                             tgt_mask))  # 先进行第一个masked 多头注意力计算。然后进行残差连接和层归一化，使用目标掩码
            x = self.sublayer[1](x, lambda x: self.src_attn(x, m, m,
                                                            src_mask))  # 然后通过第二个多头注意力，mm作为kv，在通过 self.sublayer[1] 将上一步的输出和源注意力模块 self.src_attn 进行残差连接和层归一化
            return self.sublayer[2](x, self.feed_forward)  # 在进行第三个截进分支连接，feed_forward操作 得解码器层的输出。
        else:  # layer_past 不为 None，表示这是基于之前的解码结果进行的解码过程。
            present = [None, None]
            x, present[0] = self.sublayer[0](x, lambda x: self.self_attn(x, x, x, tgt_mask, layer_past[
                0]))  # 通过子层连接(self.sublayer[0])进行自注意力计算，注意力掩码为目标掩码(tgt_mask)和过去的记忆(layer_past[0])的组合
            x, present[1] = self.sublayer[1](x, lambda x: self.src_attn(x, m, m, src_mask, layer_past[
                1]))  # 将自注意力计算的结果通过子层连接(self.sublayer[1])进行源注意力计算，注意力掩码为源掩码(src_mask)和过去的记忆(layer_past[1])的组合
            return self.sublayer[2](x, self.feed_forward), present  # 解码器的输出和当前步骤的记忆。


class MultiThreadMemory(nn.Module):  # 作用于查询和响应位置
    def __init__(self, h, d_model, dropout=0.1, topk=32):
        super(MultiThreadMemory, self).__init__()
        assert d_model % h == 0  # 整数，表示输入特征的维度。
        self.d_k = d_model // h
        self.h = h  # 输入的特征维度分成多少个头（heads）进行并行处理。
        self.linears = clones(nn.Linear(d_model, d_model), 4)
        self.fc = nn.Linear(d_model, d_model)
        nn.init.xavier_uniform_(self.fc.weight)
        self.relu = nn.ReLU()
        self.mlp = nn.Sequential(
            nn.Linear(d_model, d_model),
            nn.ReLU(),
            nn.Linear(d_model, d_model),
            nn.ReLU()
        )
        self.attn = None
        self.dropout = nn.Dropout(p=dropout)  # 浮点数，表示在计算中使用的丢弃率（dropout rate），用于随机屏蔽一些神经元，以减少过拟合。
        self.topk = topk  # 整数，表示在查询和响应阶段保留的前k个最相关的结果。

        self.norm = LayerNorm(d_model)
    def forward(self, query, key, value, mask=None,
                layer_past=None):  # 查询向量，形状为（batch_size, seq_length, d_model）。键向量，形状为（batch_size, seq_length, d_model）。值向量，形状为（batch_size, seq_length, d_model）。遮罩向量，用于屏蔽某些位置的输入，默认为None。表示过去的层输入和状态，用于实现自回归模型，默认为None。
        if mask is not None:  # 如果输入的遮罩向量mask不为None，则表示需要对输入进行遮罩操作。
            mask = mask.unsqueeze(1)  # 将遮罩向量mask的维度进行扩展，增加一个维度，使其与查询向量query的维度保持一致。这样可以确保遮罩能够正确应用于查询-键之间的注意力计算。
        nbatches = query.size(0)  # 获取查询向量query的批次大小。

        if layer_past is not None and layer_past.shape[2] == key.shape[
            1] > 1:  # 如果存在过去的层输入和状态（layer_past不为None），且过去的层输入和状态的维度与键向量key的维度匹配。
            query = self.linears[0](query)  # 将查询向量query通过线性变换self.linears[0]进行线性变换。这个线性变换可以将查询向量的维度映射到期望的维度。
            key, value = layer_past[0], layer_past[1]  # 使用过去的键和值向量替换当前的键和值向量
            present = torch.stack(
                [key, value])  # 将过去的键向量和值向量堆叠在一起，得到一个形状为(2, batch_size, seq_length, d_model)的张量present。
        else:  # 如果不存在过去的层输入和状态，或者过去的层输入和状态的维度与键向量key的维度不匹配。
            query, key, value = \
                [l(x) for l, x in zip(self.linears, (
                query, key, value))]  # 分别将查询向量query、键向量key和值向量value通过线性变换self.linears进行线性变换。这些线性变换可以将它们的维度映射到期望的维度。

        if layer_past is not None and not (
                layer_past.shape[2] == key.shape[1] > 1):  # 如果存在过去的层输入和状态，并且过去的层输入和状态的维度与键向量key的维度不匹配。
            past_key, past_value = layer_past[0], layer_past[1]  # 获取过去的键向量past_key和值向量past_value。
            key = torch.cat((past_key, key), dim=1)  # 在维度1上对过去的键向量past_key和当前的键向量key进行拼接。
            value = torch.cat((past_value, value), dim=1)  # 在维度1上对过去的值向量past_value和当前的值向量value进行拼接。
            present = torch.stack(
                [key, value])  # 将拼接后的键向量和值向量堆叠在一起，得到一个形状为(2, batch_size, seq_length, d_model)的张量present。

        query, key, value = \
            [x.view(nbatches, -1, self.h, self.d_k).transpose(1, 2)
             # 将查询向量query、键向量key和值向量value进行分割、转置和重塑操作，以便进行多头注意力计算
             for x in [query, key, value]]

        x, self.attn = memory_querying_responding(query, key, value, mask=mask, dropout=self.dropout,
                                                  topk=self.topk)  # 调用名为memory_querying_responding的函数，对查询、键和值向量进行内存查询和响应操作，得到输出向量和注意力权重

        x = x.transpose(1, 2).contiguous() \
            .view(nbatches, -1,
                  self.h * self.d_k)  # 通过线性变换将输出向量x的维度转换为最终的输出维度。将输出向量x进行转置，将多头维度self.h置换到维度1，将序列维度seq_length置换到维度2，使得每个位置的向量包含所有多头的信息。将转置后的张量x进行内存连续化，以便进行下一步的视图操作。

        # x = self.mlp(x)  # 添加MLP层和ReLU非线性激活函数
        # x = self.norm(x)
        # x = self.dropout(x)
        # #x1 = torch.tanh(x)
        # x1 = self.relu(self.fc(x))
        # x1 = self.dropout(x1)
        # x = x + x1
        # x = self.norm(x)
        # x = self.dropout(x)

        if layer_past is not None:  # 存在过去的层输入和状态
            return self.linears[-1](x), present  # 则返回输出向量和更新后的层输入和状态
        else:
            return self.linears[-1](x)  # 返回经过线性变换self.linears[-1]后的输出向量x作为最终的输出。


class MultiHeadedAttention(nn.Module):  # 用于计算atten
    def __init__(self, h, d_model, dropout=0.1):
        super(MultiHeadedAttention, self).__init__()
        assert d_model % h == 0
        self.d_k = d_model // h
        self.h = h
        self.linears = clones(nn.Linear(d_model, d_model), 4)
        self.attn = None
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, query, key, value, mask=None, layer_past=None):
        if mask is not None:
            mask = mask.unsqueeze(1)
        nbatches = query.size(0)
        if layer_past is not None and layer_past.shape[2] == key.shape[1] > 1:
            query = self.linears[0](query)
            key, value = layer_past[0], layer_past[1]
            present = torch.stack([key, value])
        else:
            query, key, value = \
                [l(x) for l, x in zip(self.linears, (query, key, value))]

        if layer_past is not None and not (layer_past.shape[2] == key.shape[1] > 1):
            past_key, past_value = layer_past[0], layer_past[1]
            key = torch.cat((past_key, key), dim=1)
            value = torch.cat((past_value, value), dim=1)
            present = torch.stack([key, value])

        query, key, value = \
            [x.view(nbatches, -1, self.h, self.d_k).transpose(1, 2)
             # origin: batchsize x sequence_num x head_num x head_dim
             for x in [query, key, value]]

        x, self.attn = attention(query, key, value, mask=mask,
                                 dropout=self.dropout)
        x = x.transpose(1, 2).contiguous() \
            .view(nbatches, -1, self.h * self.d_k)
        if layer_past is not None:
            return self.linears[-1](x), present
        else:
            return self.linears[-1](x)


class PositionwiseFeedForward(nn.Module):  # 前馈神经网络模块，用于自注意力机制等模型中，用于增强网络的非线性建模能力。
    def __init__(self, d_model, d_ff, dropout=0.1):  # 表示前馈神经网络中间层的维度。
        super(PositionwiseFeedForward, self).__init__()
        self.w_1 = nn.Linear(d_model, d_ff)
        self.w_2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        return self.w_2(self.dropout(F.relu(self.w_1(
            x))))  # 输入张量 x 通过线性变换 self.w_1，将其维度从 d_model 转换为 d_ff。对线性变换的输出应用 ReLU 激活函数。应用丢弃（dropout）操作 self.dropout 随机屏蔽一部分神经元。通过线性变换 self.w_2，将其维度从 d_ff 转换回 d_model，得到最终的输出张量


class Embeddings(nn.Module):  # 嵌入向量在自然语言处理任务中通常用于表示单词或词组，可以捕捉到它们的语义和语法信息，作为模型的输入
    def __init__(self, d_model, vocab):  # vocab表示词汇表的大小
        super(Embeddings, self).__init__()
        self.lut = nn.Embedding(vocab, d_model)  # 名为 lut 的嵌入层，它将词汇表中的单词索引映射为对应的嵌入向量。嵌入向量的维度是 d_model。
        self.d_model = d_model
        self.temp = vocab

    def forward(self, x):
        return self.lut(x) * math.sqrt(
            self.d_model)  # 嵌入层会将每个单词的索引映射为对应的嵌入向量。将嵌入向量乘以 math.sqrt(self.d_model)。这个操作是为了缩放嵌入向量，以便与模型中的其他向量具有相似的尺度。


class PositionalEncoding(nn.Module):  # 用于为序列中的每个位置生成一个固定的位置编码向量，并将其添加到输入张量中。这样做的目的是为了在模型中引入位置信息，帮助模型捕捉序列中元素的顺序关系。
    def __init__(self, d_model, dropout, max_len=5000):
        super(PositionalEncoding, self).__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, d_model)  # 创建一个形状为 (max_len, d_model) 的全零张量 pe，用于存储位置编码。
        position = torch.arange(0, max_len).unsqueeze(
            1).float()  # 表示位置的张量 position，其值从 0 到 max_len-1，并将其形状调整为 (max_len, 1)。
        div_term = torch.exp(torch.arange(0, d_model, 2).float() *
                             -(math.log(10000.0) / d_model))  # 创建一个除法项 ，用于计算位置编码中的除法项。
        pe[:, 0::2] = torch.sin(position * div_term)  # 使用正弦函数和余弦函数将位置编码的值填充到 pe 张量中
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)  # 以便与输入张量对齐。(1, max_len, d_model)

        self.register_buffer('pe', pe)  # self.register_buffer 方法将 pe 注册为模块的缓冲区，这样在训练过程中不会更新它的值。

    def forward(self, x):
        x = x + self.pe[:, :x.size(1)]  # self.pe[:, :x.size(1)]，从位置编码中提取与输入张量 x 的长度相对应的部分。将提取的位置编码与输入张量相加，以将位置编码应用于输入。
        return self.dropout(x)  # 将结果张量传递给丢弃层 self.dropout 进行随机屏蔽。


class EncoderDecoder(AttModel):

    def make_model(self, tgt_vocab, cmn):  # 接受目标词汇表大小和cmn作为参数
        c = copy.deepcopy  # 进行一些深拷贝操作
        attn = MultiHeadedAttention(self.num_heads, self.d_model)
        ff = PositionwiseFeedForward(self.d_model, self.d_ff, self.dropout)
        position = PositionalEncoding(self.d_model, self.dropout)
        model = Transformer(
            Encoder(EncoderLayer(self.d_model, c(attn), c(ff), self.dropout), self.num_layers),
            Decoder(DecoderLayer(self.d_model, c(attn), c(attn), c(ff), self.dropout), self.num_layers),
            nn.Sequential(c(position)),
            nn.Sequential(Embeddings(self.d_model, tgt_vocab), c(position)),
            cmn
        )
        for p in model.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)
        return model

    def __init__(self, args, tokenizer, mode='train'):
        super(EncoderDecoder, self).__init__(args, tokenizer)  # tokenizer用于文本处理的分词器
        self.args = args
        self.num_layers = args.num_layers
        self.d_model = args.d_model
        self.d_ff = args.d_ff
        self.num_heads = args.num_heads
        self.dropout = args.dropout
        self.topk = args.topk
        self.num_cluster = args.num_cluster
        self.img_margin = args.img_con_margin
        self.txt_margin = args.txt_con_margin
        self.num_protype = args.num_protype

        self.img_cls_head = nn.Sequential(nn.Linear(args.cmm_dim, args.cmm_dim),
                                          nn.Linear(args.cmm_dim, 14))  # 一个包含两个线性层的顺序模型，用于图像分类任务。

        self.txt_cls_head = nn.Sequential(nn.Linear(args.cmm_dim, args.cmm_dim),
                                          nn.Linear(args.cmm_dim, 14))  # 一个包含两个线性层的顺序模型，用于文本分类任务。

        self.txt_dim_reduction = nn.Linear(args.d_txt_ebd, args.cmm_dim)  # 一个线性层，用于将文本嵌入的维度降低到公共表示维度。

        self.dim_reduction = nn.Linear(args.d_txt_ebd + args.d_img_ebd, args.cmm_dim)  # 一个线性层，用于将文本和图像嵌入的维度降低到公共表示维度。

        self.img_dim_reduction = nn.Linear(args.d_img_ebd, args.cmm_dim)  # 一个线性层，用于将图像嵌入的维度降低到公共表示维度。

        self.fuse_feature = nn.Linear(args.d_model * 2, args.d_model)  # 一个线性层，用于融合文本和图像特征。

        tgt_vocab = self.vocab_size + 1

        self.cmn = MultiThreadMemory(args.num_heads, args.d_model, topk=args.topk)  # 一个MultiThreadMemory类的实例，用于多线程内存操作。

        self.model = self.make_model(tgt_vocab, self.cmn)  # 调用make_model方法构建的Transformer模型
        self.logit = nn.Linear(args.d_model, tgt_vocab)  # 一个线性层，用于将Transformer模型的输出映射到目标词汇表的维度。

        self.protypes = nn.Parameter(torch.FloatTensor(args.num_protype * args.num_cluster,
                                                       args.d_txt_ebd + args.d_img_ebd))  # 一个可训练的张量参数，表示原型向量，形状为（num_protype * num_cluster, d_txt_ebd + d_img_ebd）。
        if mode == 'train':
            init_protypes = torch.load(args.init_protypes_path).float()
            self.protypes = nn.Parameter(init_protypes)

    def init_hidden(self, bsz):
        return []

    def _prepare_feature(self, fc_feats, att_feats, att_masks,
                         labels=None):  # 接受输入的特征向量 fc_feats、att_feats、att_masks，以及可选的标签 labels
        att_feats, seq, att_masks, seq_mask, query_matrix, cmn_masks, _ = \
            self._prepare_feature_forward(att_feats, att_masks, labels=labels)  # 经过一些处理的特征向量、注意力掩码等
        memory = self.model.encode(att_feats, att_masks)  # 通过调用模型的 encode 方法对注意力特征进行编码，得到编码后的记忆 memory。

        return fc_feats[..., :1], att_feats[..., :1], memory, att_masks, labels, query_matrix, cmn_masks

    def _prepare_feature_forward(self, att_feats, att_masks=None, seq=None, labels=None, ):

        att_feats, att_masks = self.clip_att(att_feats, att_masks)  # 对注意力特征和注意力掩码进行剪裁注意力特征
        att_feats = pack_wrapper(self.att_embed, att_feats, att_masks)  # pack_wrapper 函数对剪裁后的注意力特征进行打包

        if att_masks is None:  # 如果注意力掩码为 None，则创建一个与注意力特征形状相同的全1张量作为注意力掩码。
            att_masks = att_feats.new_ones(att_feats.shape[:2], dtype=torch.long)

        max_num_protype = max(labels.sum(
            -1)) * self.num_protype  # 计算每个样本中正样本的数量，并乘以 self.num_protype，得到最大原型数量 max_num_protype。这个值表示每个样本在查询矩阵中最多可以使用的原型数量。
        protypes = self.dim_reduction(self.protypes)  # 对原型向量张量 self.protypes 进行维度缩减或转换的操作，得到降维后的原型向量张量 protypes
        query_matrix = protypes.new_zeros(att_feats.size(0), max_num_protype.int(), protypes.shape[
            -1])  # 创建一个与 protypes 张量具有相同数据类型的全零张量 query_matrix，该张量的形状是 (att_feats.size(0), max_num_protype.int(), protypes.shape[-1])，其中 att_feats.size(0) 表示批次大小，max_num_protype.int() 表示最大原型数量，protypes.shape[-1] 表示原型向量的特征维度。这个张量将用于存储查询矩阵的结果。根据标签信息和原型向量，构造查询矩阵 query_matrix 和共享注意力掩码 cmn_masks  也就是跨模态原型矩阵
        cmn_masks = protypes.new_zeros(query_matrix.shape[0], att_feats.size(1), max_num_protype.int())
        # 根据标签为1的位置选择相应的原型向量，并将其存储在查询矩阵中。同时，构造共享注意力掩码，用于指示哪些原型向量是有效的。
        for i in range(att_feats.size(0)):  # 根据标签信息从原型向量张量中选择相应的原型向量，并构建查询矩阵 query_matrix 和掩码矩阵 cmn_masks
            cur_query_matrix = []  # 用于存储当前样本的查询矩阵。
            for j in range(len(labels[i])):
                if labels[i, j] == 1:  # 如果 labels[i, j] 的值等于 1，表示该位置对应的标签为正样本。
                    cur_query_matrix.extend(
                        protypes[j * self.num_protype:(j + 1) * self.num_protype,
                        :])  # 从原型向量张量 protypes 中选择相应的原型向量，并将其添加到 cur_query_matrix 列表中。
            cur_query_matrix = torch.stack(cur_query_matrix, 0)  # 将 cur_query_matrix 列表转换为张量

            query_matrix[i, :cur_query_matrix.shape[0], :] = cur_query_matrix
            cmn_masks[i, :, :cur_query_matrix.shape[0]] = 1

        responses = self.cmn(att_feats, query_matrix, query_matrix,
                             cmn_masks)  # 调用 cmn 的方法，将注意力特征和查询矩阵传递给共享内存模块，得到响应结果 responses。

        # feature interaction
        att_feats = self.fuse_feature(torch.cat((att_feats, responses),
                                                dim=2))  # 将图像注意力特征和响应结果进行拼接，并经过线性变换（全连接层）图像特征concat部分，得到融合后的特征向量 att_feats。

        att_masks = att_masks.unsqueeze(-2)  # 根据需要，对输入序列进行修剪和生成序列掩码
        if seq is not None:
            seq = seq[:, :-1]
            seq_mask = (seq.data > 0)
            seq_mask[:, 0] += True

            seq_mask = seq_mask.unsqueeze(-2)
            seq_mask = seq_mask & subsequent_mask(seq.size(-1)).to(seq_mask)
        else:
            seq_mask = None

        return att_feats, seq, att_masks, seq_mask, query_matrix, cmn_masks[:, 0, :], responses

    def _forward(self, fc_feats, att_feats, seq, att_masks=None, labels=None):
        att_feats, seq, att_masks, seq_mask, query_matrix, cmn_masks, img_responses = \
            self._prepare_feature_forward(att_feats, att_masks, seq,
                                          labels)  # 调用 _prepare_feature_forward 方法对输入特征进行准备，得到经过处理的注意力特征、序列、注意力掩码、序列掩码、查询矩阵、共享注意力掩码和图像响应结果。
        out, txt_feats, txt_responses = self.model(att_feats, seq, att_masks, seq_mask, memory_matrix=query_matrix,
                                                   # 将处理后的特征和信息传递给模型的 model 方法进行前向计算，返回模型的输出 out、文本特征 txt_feats 和文本响应结果 txt_responses。
                                                   cmn_masks=cmn_masks, labels=labels)
        outputs = F.log_softmax(self.logit(out), dim=-1)  # 对模型的输出应用对数softmax函数，得到分类的概率分布 outputs。
        img_con_loss = my_con_loss(torch.mean(img_responses, dim=1), num_classes=self.num_cluster,
                                   # 图像响应结果、标签和一些超参数，计算图像响应结果的对比损失 img_con_loss。对比损失用于鼓励图像响应结果在同一类别内相互靠近，不同类别之间相互远离。
                                   num_protypes=self.num_protype, labels=labels, margin=self.img_margin)
        img_con_loss = img_con_loss.unsqueeze(0)  # for  multi-gpu setting
        txt_con_loss = my_con_loss(torch.mean(txt_responses, dim=1), num_classes=self.num_cluster,
                                   # 类似地，计算文本响应结果的对比损失 txt_con_loss。
                                   num_protypes=self.num_protype, labels=labels, margin=self.txt_margin)
        txt_con_loss = txt_con_loss.unsqueeze(0)  # for  multi-gpu setting

        img_bce_loss = self.img_cls_head(torch.mean(att_feats,
                                                    dim=1))  # 通过图像分类头部模型 img_cls_head 和文本分类头部模型 txt_cls_head，对图像特征和文本特征进行分类，得到图像分类的交叉熵损失 img_bce_loss 和文本分类的交叉熵损失 txt_bce_loss。
        txt_bce_loss = self.txt_cls_head(torch.mean(txt_feats, dim=1))

        return outputs, img_con_loss, txt_con_loss, img_bce_loss, txt_bce_loss  # 将输出的分类概率分布、图像对比损失、文本对比损失、图像交叉熵损失和文本交叉熵损失作为元组返回。

    def core(self, it, fc_feats_ph, att_feats_ph, memory, state, mask, query_matrix, cmn_masks,
             labels=None):  # 核心解码部分，接受输入的标记 it、图像特征占位符 fc_feats_ph、注意力特征占位符 att_feats_ph、记忆 memory、状态 state、掩码 mask、查询矩阵 query_matrix、共享注意力掩码 cmn_masks 和标签 labels（可选）作为输入。
        if len(state) == 0:  # 检查状态 state 的长度，如果为空，则表示为解码的第一步
            ys = it.unsqueeze(1)  # 将当前的标记 it 添加到序列 ys 中，并初始化过去状态 past 为全零张量。

            past = [fc_feats_ph.new_zeros(self.num_layers * 2, fc_feats_ph.shape[0], 0, self.d_model),
                    fc_feats_ph.new_zeros(self.num_layers * 2, fc_feats_ph.shape[0], 0, self.d_model)]
        else:
            ys = torch.cat([state[0][0], it.unsqueeze(1)], dim=1)  # 将当前的标记 it 添加到序列 ys 的末尾，并
            past = state[1:]  # 将过去状态 past 设置为输入状态 state 的第二个元素开始的部分。

        [out, past], embeddings, responses= self.model.decode(memory, mask, ys,
                                                                    subsequent_mask(ys.size(1)).to(memory.device),
                                                                    past=past,
                                                                    memory_matrix=query_matrix, cmn_masks=cmn_masks,
                                                                    labels=labels)
        return out[:, -1], [ys.unsqueeze(0)] + past  # 从解码输出 out 中提取最后一个时间步的结果，并将序列 ys 和更新后的过去状态 past（作为列表）作为结果返回。

